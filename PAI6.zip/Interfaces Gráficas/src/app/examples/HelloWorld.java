package app.examples;
//hola guapo
public class HelloWorld {
	public static void main(String[] args) {
		int n = 2;
		String s = "Hola Mundo";
		System.out.print(s + n);
	}
}

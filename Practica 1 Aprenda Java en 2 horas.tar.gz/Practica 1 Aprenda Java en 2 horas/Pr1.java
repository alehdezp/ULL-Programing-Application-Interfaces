class Pr1 {
   public static void main (String[] args) {
	System.out.println("Mi primer programa en Java");
	}
}

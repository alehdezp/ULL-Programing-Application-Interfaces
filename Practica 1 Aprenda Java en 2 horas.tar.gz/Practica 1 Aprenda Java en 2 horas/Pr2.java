class Pr2 {
   public static void main (String[] args) {
      Pair p1 = new Pair(1, 1);
      Pair p2 = new Pair(1, 1);
      System.out.println("El par es" + p1);
      System.out.println(p1.equals(p2));
   }
}

